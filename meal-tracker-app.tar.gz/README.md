# 🍽️ Meal Tracker App

An AI-powered meal tracking application that uses your phone's camera to scan meals, calculates macros (calories, protein, carbs, fat, fiber), and tracks your daily steps.

## Features

- 📸 **Camera Scanning** - Take photos of your meals with your phone camera
- 🤖 **AI Analysis** - Uses Claude AI to identify food items and calculate nutritional values
- 📊 **Macro Tracking** - Tracks calories, protein, carbs, fat, and fiber
- 👟 **Step Counter** - Monitor your daily steps (mobile only)
- 💾 **Persistent Storage** - Meals saved locally in your browser
- 📱 **Mobile Optimized** - Works great on both desktop and mobile

## Tech Stack

- **Frontend**: React (vanilla), Tailwind CSS
- **Backend**: Node.js, Express
- **AI**: Anthropic Claude API
- **Deployment**: Render (recommended) or any Node.js hosting

## Prerequisites

- Node.js 18+ installed
- Anthropic API key ([Get one here](https://console.anthropic.com/))
- Git installed

## Local Development Setup

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd meal-tracker-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` and add your Anthropic API key:
   ```
   ANTHROPIC_API_KEY=your_actual_api_key_here
   PORT=3000
   ```

4. **Run the development server**
   ```bash
   npm start
   ```

5. **Open your browser**
   ```
   http://localhost:3000
   ```

## Deployment Instructions

### Option 1: Deploy to Render (Recommended - Free Tier Available)

1. **Push your code to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin <your-github-repo-url>
   git push -u origin main
   ```

2. **Create a Render account**
   - Go to [render.com](https://render.com)
   - Sign up with GitHub

3. **Create a new Web Service**
   - Click "New +" → "Web Service"
   - Connect your GitHub repository
   - Configure:
     - **Name**: meal-tracker-app (or your choice)
     - **Environment**: Node
     - **Build Command**: `npm install`
     - **Start Command**: `npm start`
     - **Instance Type**: Free

4. **Add Environment Variable**
   - In Render dashboard → Environment
   - Add: `ANTHROPIC_API_KEY` = your API key

5. **Deploy**
   - Click "Create Web Service"
   - Render will automatically deploy
   - Your app will be live at: `https://your-app-name.onrender.com`

### Option 2: Deploy to Railway

1. **Install Railway CLI**
   ```bash
   npm install -g @railway/cli
   ```

2. **Login and deploy**
   ```bash
   railway login
   railway init
   railway add
   railway up
   ```

3. **Set environment variables**
   ```bash
   railway variables set ANTHROPIC_API_KEY=your_api_key_here
   ```

### Option 3: Deploy to Heroku

1. **Install Heroku CLI**
   ```bash
   npm install -g heroku
   ```

2. **Create and deploy**
   ```bash
   heroku login
   heroku create meal-tracker-app
   heroku config:set ANTHROPIC_API_KEY=your_api_key_here
   git push heroku main
   ```

## GitHub Actions Setup

The repository includes a GitHub Actions workflow (`.github/workflows/deploy.yml`) that:
- Runs on every push to `main` branch
- Installs dependencies
- Validates the build

For automatic deployment, Render/Railway/Heroku will auto-deploy when you push to GitHub.

## API Endpoints

### `GET /api/health`
Health check endpoint
```json
{
  "status": "ok",
  "message": "Meal Tracker API is running"
}
```

### `POST /api/analyze-meal`
Analyze a meal image

**Request Body:**
```json
{
  "imageData": "data:image/jpeg;base64,..."
}
```

**Response:**
```json
{
  "name": "Grilled Chicken Salad",
  "items": ["grilled chicken breast", "mixed greens", "cherry tomatoes"],
  "calories": 350,
  "protein": 45,
  "carbs": 15,
  "fat": 12,
  "fiber": 5
}
```

## Project Structure

```
meal-tracker-app/
├── .github/
│   └── workflows/
│       └── deploy.yml       # GitHub Actions workflow
├── public/
│   └── index.html          # Frontend React app
├── server.js               # Express backend server
├── package.json            # Dependencies
├── .env.example            # Environment variables template
├── .gitignore             # Git ignore rules
└── README.md              # This file
```

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `ANTHROPIC_API_KEY` | Your Anthropic API key | Yes |
| `PORT` | Server port (default: 3000) | No |

## How to Use

1. **Open the app** on your phone or computer
2. **Upload or scan a meal** using the camera or file upload
3. **Wait for AI analysis** - Claude will identify foods and calculate macros
4. **View your daily totals** - See all nutrition stats at a glance
5. **Enable step counter** (mobile only) - Track your steps throughout the day

## Cost Considerations

- **Anthropic API**: Pay-as-you-go pricing
  - ~$0.003 per image analysis
  - First $5 of usage is free (credit may vary)
- **Hosting**: 
  - Render Free Tier: Free (with limitations)
  - Railway: $5/month after free tier
  - Heroku: $7/month (Eco dyno)

## Troubleshooting

**Camera not working?**
- Grant camera permissions in your browser
- Use "Upload Photo" instead on desktop

**API errors?**
- Check your ANTHROPIC_API_KEY is set correctly
- Verify the backend server is running
- Check browser console for error messages

**Step counter not working?**
- Only works on mobile devices with accelerometers
- Requires motion sensor permissions

## License

MIT License - feel free to use this project however you'd like!

## Contributing

Pull requests are welcome! For major changes, please open an issue first.

## Support

If you encounter any issues, please open a GitHub issue with:
- Description of the problem
- Screenshots (if applicable)
- Browser/device information
